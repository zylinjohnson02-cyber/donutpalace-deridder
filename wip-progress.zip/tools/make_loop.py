#!/usr/bin/env python3
"""Make a seamless loop from a clip by crossfading its tail into its head.

out[k] = src[X+k]                                   for k <  L-X
out[k] = (1-a)*src[X+k] + a*src[j],  a=(j+1)/(X+1)  for k >= L-X, j = k-(L-X)
where N = number of source frames, X = crossfade frames, L = N - X.
The last output frame is ~src[X-1], so wrapping to out[0] = src[X] is continuous.

Frames are blended as float in RGB and piped losslessly (rgb24) to ffmpeg,
which upscales (lanczos + light CAS) and writes a high-quality master.
"""
import subprocess, sys
import cv2
import numpy as np

src, dst, xfade_frames, out_w, out_h = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
fps = 24

cap = cv2.VideoCapture(src)
frames = []
while True:
    ok, f = cap.read()
    if not ok:
        break
    frames.append(f)
N = len(frames)
X = xfade_frames
L = N - X
h, w = frames[0].shape[:2]
print(f"source {w}x{h} frames={N} -> loop frames={L} ({L/fps:.3f}s), xfade={X}")

ff = subprocess.Popen([
    "ffmpeg", "-v", "error", "-y",
    "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{w}x{h}", "-r", str(fps), "-i", "-",
    "-vf", f"scale={out_w}:{out_h}:flags=lanczos+accurate_rnd,cas=strength=0.3,format=yuv420p",
    "-c:v", "libx264", "-preset", "slow", "-crf", "12", "-an",
    "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
    dst,
], stdin=subprocess.PIPE)

for k in range(L):
    a_frame = frames[X + k]
    if k < L - X:
        out = a_frame
    else:
        j = k - (L - X)
        a = (j + 1) / (X + 1)
        out = cv2.addWeighted(a_frame.astype(np.float32), 1 - a, frames[j].astype(np.float32), a, 0)
        out = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    ff.stdin.write(out.tobytes())
ff.stdin.close()
ff.wait()
print("done", dst)
